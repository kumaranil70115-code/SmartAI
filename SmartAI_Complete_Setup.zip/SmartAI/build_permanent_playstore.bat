@echo off
title Smart AI - Permanent Play Store Builder (24/7 Cloud Edition)
color 0b
cd /d "%~dp0"

echo ======================================================================
echo    SMART AI - PERMANENT GOOGLE PLAY STORE BUILDER (24/7 CLOUD)
echo ======================================================================
echo.
echo Is tool se aap Smart AI ko 24/7 PERMANENT SERVER ke sath connect karke
echo Google Play Store (.aab) bundle aur Android APK package generate kar sakte hain!
echo Isse aapka app kisi bhi phone par 24 ghante chalega, chahe computer band ho!
echo.
echo ----------------------------------------------------------------------
echo  STEP 1: PERMANENT CLOUD SERVER URL SET KAREIN
echo ----------------------------------------------------------------------
echo.

set "DEFAULT_CLOUD_URL=https://smart-ai-assistant.onrender.com"
set /p PERM_URL="Apna Permanent Cloud Server HTTPS URL enter karein [Default: %DEFAULT_CLOUD_URL%]: "

if "%PERM_URL%"=="" set "PERM_URL=%DEFAULT_CLOUD_URL%"

echo.
echo [OK] Selected Permanent URL: %PERM_URL%
echo.

echo ----------------------------------------------------------------------
echo  CHOOSE PACKAGING METHOD:
echo ----------------------------------------------------------------------
echo  [1] 1-Click Official PWABuilder (Google Play Store AAB + APK - Recommended)
echo  [2] Google Bubblewrap CLI se Local AAB aur Signed APK Build karein
echo  [3] AssetLinks Fingerprint Helper (Google Play Store Digital Asset Links)
echo  [4] Full Step-by-Step Play Store Publish Guide dekhein
echo  [5] Exit
echo ----------------------------------------------------------------------
echo.

set /p choice="Apna option number chunein (1-5): "

if "%choice%"=="1" goto pwabuilder
if "%choice%"=="2" goto bubblewrap
if "%choice%"=="3" goto assetlinks
if "%choice%"=="4" goto playstore_guide
if "%choice%"=="5" goto end
goto menu_retry

:pwabuilder
cls
echo ======================================================================
echo    OPTION 1: PWABUILDER (OFFICIAL GOOGLE PLAY STORE PACKAGER)
echo ======================================================================
echo.
echo PWABuilder Microsoft aur Google ka official tool hai jo aapke
echo Permanent Cloud URL ko scan karke direct Google Play Store ka:
echo   - App Bundle (.aab file)
echo   - Universal Android APK (.apk file)
echo   - Google Play Signing Key
echo 1-Click me download karwa deta hai!
echo.
echo Step 1: URL copy ho gaya hai: %PERM_URL%
echo Step 2: Browser me PWABuilder open ho raha hai...
echo Step 3: Wahan apna URL paste karke 'Start' dabayein.
echo Step 4: 'Package For Stores' par tap karke 'Google Play' -> 'Generate Package' dabayein!
echo.
echo Clip me URL copy kar rahe hain...
powershell -Command "Set-Clipboard -Value '%PERM_URL%'" 2>nul
pause
start https://www.pwabuilder.com/
goto end

:bubblewrap
cls
echo ======================================================================
echo    OPTION 2: GOOGLE BUBBLEWRAP CLI (LOCAL NATIVE APK/AAB BUILD)
echo ======================================================================
echo.
echo Checking Node.js installation...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js aapke computer par install nahi hai.
    echo Kripya pehle https://nodejs.org se Node.js install karein.
    pause
    goto end
)
echo [OK] Node.js mil gaya.
echo.
echo Installing / Updating Google Bubblewrap CLI (@bubblewrap/cli)...
call npm install -g @bubblewrap/cli
echo.
echo Bubblewrap initialization shuru ho raha hai:
echo Target Manifest: %PERM_URL%/manifest.json
echo.
call bubblewrap init --manifest="%PERM_URL%/manifest.json"
echo.
echo Bubblewrap build command chala rahe hain (AAB and APK generate hoga)...
call bubblewrap build
pause
goto end

:assetlinks
cls
echo ======================================================================
echo    OPTION 3: DIGITAL ASSET LINKS (assetlinks.json) SETUP
echo ======================================================================
echo.
echo Jab aap Play Store par app submit karte hain, tab Google Play Console
echo aapko ek 'App signing key certificate SHA-256 fingerprint' deta hai.
echo.
echo Yeh fingerprint 'web/.well-known/assetlinks.json' me dali jati hai
echo taki app phone par full screen (bina browser address bar ke) open ho.
echo.
echo Current AssetLinks file: web\.well-known\assetlinks.json
echo.
set /p SHA_INPUT="Play Console ka SHA-256 Fingerprint paste karein (ya Enter dabayein skip karne ke liye): "
if not "%SHA_INPUT%"=="" (
    python -c "
import json
p = 'web/.well-known/assetlinks.json'
with open(p, 'w', encoding='utf-8') as f:
    f.write(json.dumps([{'relation': ['delegate_permission/common.handle_all_urls'], 'target': {'namespace': 'android_app', 'package_name': 'com.smartai.assistant', 'sha256_cert_fingerprints': ['%SHA_INPUT%']}}], indent=2))
print('[SUCCESS] assetlinks.json successfully updated!')
"
)
pause
goto end

:playstore_guide
cls
echo ======================================================================
echo    OPTION 4: GOOGLE PLAY STORE PUBLISHING GUIDE (STEP-BY-STEP)
echo ======================================================================
echo.
echo 1. Google Play Console Account:
echo    - https://play.google.com/console par jayein ($25 one-time registration).
echo.
echo 2. Permanent Cloud Deployment (24/7 Online):
echo    - Pehle Smart AI ko Render.com ya Railway par deploy karein.
echo    - Isse aapko permanent HTTPS URL milta hai.
echo.
echo 3. App Bundle (.aab) Download:
echo    - PWABuilder (Option 1) se Play Store .zip download karein.
echo    - Uske andar signed .aab file hogi.
echo.
echo 4. Play Console me Upload:
echo    - Play Console -> 'Create App' -> Name: 'Smart AI - Hindi Voice Assistant'
echo    - 'Release' -> 'Production' -> .aab file drag and drop karein.
echo.
echo 5. Digital Asset Links:
echo    - Play Console -> Setup -> App Signing -> SHA-256 fingerprint copy karein.
echo    - Option 3 se ya web/.well-known/assetlinks.json me paste karke save karein.
echo.
echo 6. Review & Live:
echo    - Submit for review dabayein. 24-48 ghanto me Play Store par live ho jayega!
echo.
pause
goto end

:menu_retry
echo Galat choice! Kripya 1 se 5 ke beech chunein.
pause
goto end

:end
echo.
echo Smart AI Play Store Builder complete.
